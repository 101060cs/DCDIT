This is the data crawled from the VLDB database consisting of 11 top conferences, which are KDD, ICDE, ICDM, VLDB, SIGMOD, AAAI, IJCAI, ICML, NIPS, CVPR, ICCV and ECCV.
This folder contains one Matlab .Mat file.

1. OriginalMat.mat
-- The Matlab .mat file contains the processed graph streams. It contains A total of 11 graph streams, representing publications during the 11 years from 2001 to 2011. It has the following structure.
G=OriginalMat{i};% The i-th network.
G{1} -- The node set, a cell structure containing author names and paper titles. For instance, G{1}{i}{1} stores the author name of the node i, G{1}{i}{2} stores the paper title as node content of node i.
G{2} -- The edge set, a cell structure containing author pairs and co-authored paper title. For instance, G{2}{i}{1} stores the author pair of the edge i, G{2}{i}{2} stores the paper title as edge content of edge i. 
G{3} -- The paper type corresponding to G{1}. G{1} and G{3} are of the same length.


-- By Chang-Dong Wang
-- Sun Yat-sen University and University of Illinois at Chicago.
-- Email: changdongwang@hotmail.com
-- 09/23/2012.