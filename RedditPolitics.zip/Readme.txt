This is the data crawled from Politics subreddit in http://www.reddit.com/r/politics/
This folder contains two Matlab .Mat files and one subfolder.

1. AllRedditMoviesPostURLs.mat
-- The Matlab .mat file contains all the crawled URLs. A cell structure with each cell containing one URL.

2. RedditMoviesOriginal.mat
-- The Matlab .mat file contains the crawled threads. A cell structure with each cell containing one structure presenting one threads: URL, Post, Comments.

3. Folder "RedditMovies".
-- The folder contains the unprocessed posts. Each .txt file contains one post.



-- By Chang-Dong Wang
-- Sun Yat-sen University and University of Illinois at Chicago.
-- Email: changdongwang@hotmail.com
-- 09/23/2012.